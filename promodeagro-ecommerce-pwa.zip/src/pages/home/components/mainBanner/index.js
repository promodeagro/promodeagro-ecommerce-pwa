import React, { Component } from "react";


class MainBanner extends Component {
 

  render() {
    return (
      <div className="main-banner">
      </div>
    );
  }
}

export default MainBanner;
