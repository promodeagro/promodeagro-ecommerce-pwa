import React, { Component } from "react";
import {
  Box,
  Container,
  Button,
  TextField,
  InputAdornment,
  Checkbox,
  Divider,
} from "@mui/material";

class OtpModal extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <Box className="OtpModal-container">
        <Container></Container>
      </Box>
    );
  }
}

export default OtpModal;
